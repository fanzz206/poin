
const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = ""
global.namaowner = "LexzyMarket"


//~~~~~~~~~SETTING PAIRING~~~~~~~~~~//
global.Qr = false
//GANTI TRUE JADI QR/SCAN
// FALSE JADI PAIRING KODE

//~~~~~~~~~SETTING PAYMENT~~~~~~~~~~//
global.dana = "08xxxx"
global.ovo = "08xxxx"
global.gopay = "08xxxx"
global.qris = "https://b.top4top.io/p_3279htla70.jpg"

//~~~~~~~~~SETTING DELAY~~~~~~~~~~//
global.delaypushkontak
global.delayjpm = "3000"

//~~~~~~~~~SETTING CPANEL~~~~~~~~~~//
global.egg = "15"
global.loc = "1"
global.domain = "https://" // DOMAIN
global.apikey = "" // PTLA
global.capikey = "" // PTLC

//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "    _*Khusus Boss Gw!!*_",
    prem: "   _*Khusus Yang Udah Di Akses Boss Gw!!*_",
    gb: "    _*Khusus Dalam Group Bos!!*_",
    adm: "    _*Khusus Admin Lu Member Dongo!!*_",
    b: "    _*Bot Blum Jadi Admin Boss!!*_"
}


let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
